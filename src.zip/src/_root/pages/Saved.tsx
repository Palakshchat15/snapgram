import React from 'react'

const Saved = () => {
  return (
    <div>Saved</div>
  )
}

export default Saved