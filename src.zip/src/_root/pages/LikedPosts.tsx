import React from 'react'

const LikedPosts = () => {
  return (
    <div>LikedPosts</div>
  )
}

export default LikedPosts