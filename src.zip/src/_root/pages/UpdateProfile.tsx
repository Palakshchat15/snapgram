import React from 'react'

const UpdateProfile = () => {
  return (
    <div>UpdateProfile</div>
  )
}

export default UpdateProfile